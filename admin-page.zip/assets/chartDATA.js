




export const chartDATA = {
  a:{
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
          label: 'Course',
          data: [94, 170, 256, 378, 480, 483, 501, 574, 608, 640, 700, 704],
          backgroundColor: 'rgba(37, 99, 235, 0.4)',
          borderColor: 'rgba(37, 99, 235, 0.8)',
          borderWidth: 1,
        },
        {
          label: 'Article',
          data: [14, 35, 77, 102, 107, 124, 138, 149, 179, 201, 270, 302],
          backgroundColor: 'rgba(5, 150, 105, 0.4)',
          borderColor: 'rgba(5, 150, 105, 0.8)',
          borderWidth: 1
        }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          min: 0,
          ticks: {
            color: '#dde7ff',
            font: "IRANSans"
          },
          grid: {
            color: '#262c39',
            borderColor: '#485164',
            tickColor: 'transparent'
          }
        },
        x: {
          display: true,
          ticks: {
            color: '#dde7ff',
            font: "IRANSans"
          },
          grid: {
            color: '#262c39',
            borderColor: '#485164',
            tickColor: 'transparent'
          }
        },
      },
    },
  },





  b:{
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [{
        label: 'course visits',
        data: [12, 19, 3, 5, 2, 3, 3, 5, 3, 3],
        backgroundColor: 'rgba(37, 99, 235, 0.4)',
        borderColor: 'rgba(37, 99, 235, 0.8)',
        borderWidth: 1,
      },]
    },
    options: {
      responsive: true,
      barValueSpacing: 2,
      maintainAspectRatio: false,
      title: {
        text: 'Chart Title',
      },
      scales: {
        y: {
          min: 0,
          ticks: {
            color: '#dde7ff',
            font: "IRANSans"
          },
          grid: {
            color: '#262c39',
            borderColor: '#485164',
            tickColor: 'transparent'
          }
        },
        x: {
          display: true,
          ticks: {
            color: '#dde7ff',
            font: "IRANSans"
          },
          grid: {
            color: '#262c39',
            borderColor: '#485164',
            tickColor: 'transparent'
          }
        },
      },
      legend: {
        labels: {
          font: {}
        }
      }
    },
  },





  c:{
    type: 'doughnut',
    data: {
      labels: ['Red', 'Blue'],
      datasets: [{
          data: [14, 10],
          backgroundColor: [
            'transparent',
            'rgba(75, 192, 192, 0.2)',
          ],
          borderColor: [
            'rgba(75, 192, 192, 1)',
            'transparent',
          ],
          borderWidth: 1,
        }]
    },
    options: {
      plugins:{
        legend: {
          display: false
        },
        tooltip:{
          enabled: false
        }
      },
      responsive: true,
      maintainAspectRatio: false,
    },
  },
}











